package com.raylan.vrxotmz.data

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.raylan.vrxotmz.model.DefaultTweaksProvider
import com.raylan.vrxotmz.model.FpsMode
import com.raylan.vrxotmz.model.InstalledGame
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class PreparedProfileSnapshot(
  val packageName: String?,
  val gameName: String?,
  val fpsMode: FpsMode,
  val enabledTweakIds: Set<String>,
)

class GameRepository(private val context: Context) {

  companion object {
    private const val PREFS_NAME = "vrx_otmz_prefs"
    private const val KEY_SELECTED_PACKAGE = "selected_package"
    private const val KEY_SELECTED_GAME_NAME = "selected_game_name"
    private const val KEY_SELECTED_FPS_MODE = "selected_fps_mode"
    private const val KEY_ENABLED_TWEAKS = "enabled_tweaks"

    val FEATURED_SPECS =
      listOf(
        FeaturedGameSpec("Roblox", "com.roblox.client"),
        FeaturedGameSpec("Free Fire", "com.dts.freefireth"),
        FeaturedGameSpec("Free Fire MAX", "com.dts.freefiremax"),
      )

    private val KNOWN_GAME_PACKAGES =
      setOf(
        "com.roblox.client",
        "com.dts.freefireth",
        "com.dts.freefiremax",
        "com.tencent.ig",
        "com.activision.callofduty.shooter",
        "com.miHoYo.GenshinImpact",
        "com.supercell.brawlstars",
        "com.supercell.clashroyale",
        "com.mobile.legends",
        "com.mojang.minecraftpe",
        "com.epicgames.fortnite",
        "com.garena.game.codm",
        "com.ea.gp.fifamobile",
        "com.kiloo.subwaysurf",
        "com.axlebolt.standoff2",
      )
  }

  data class FeaturedGameSpec(val defaultName: String, val packageName: String)

  private val prefs by lazy {
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
  }

  suspend fun loadInstalledGames(): Pair<List<InstalledGame>, List<InstalledGame>> =
    withContext(Dispatchers.IO) {
      val pm = context.packageManager
      val selfPkg = runCatching { context.packageName }.getOrDefault("")

      val launchablePackages: Set<String> =
        runCatching {
            val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            pm.queryIntentActivities(launcherIntent, PackageManager.MATCH_ALL)
              .mapNotNull { it.activityInfo?.packageName }
              .toSet()
          }
          .getOrDefault(emptySet())

      val installedApps: Map<String, ApplicationInfo> =
        runCatching {
            pm.getInstalledApplications(PackageManager.GET_META_DATA)
              .filter { info ->
                info.packageName != selfPkg &&
                  (launchablePackages.contains(info.packageName) ||
                    (info.flags and ApplicationInfo.FLAG_SYSTEM) == 0)
              }
              .associateBy { it.packageName }
          }
          .getOrDefault(emptyMap())

      val featuredList =
        FEATURED_SPECS.map { spec ->
          val info = installedApps[spec.packageName]
          val label =
            if (info != null) {
              runCatching { pm.getApplicationLabel(info).toString() }.getOrDefault(spec.defaultName)
            } else {
              spec.defaultName
            }
          val icon =
            if (info != null) {
              runCatching { drawableToImageBitmap(pm.getApplicationIcon(info)) }.getOrNull()
            } else {
              null
            }
          InstalledGame(
            appName = label,
            packageName = spec.packageName,
            isFeatured = true,
            isGameCategory = true,
            isInstalled = info != null,
            iconBitmap = icon,
          )
        }

      val featuredPackages = FEATURED_SPECS.map { it.packageName }.toSet()

      val allInstalled =
        installedApps.values
          .mapNotNull { info ->
            runCatching {
                val pkg = info.packageName
                val appName = pm.getApplicationLabel(info).toString().ifBlank { pkg }
                val isGame =
                  info.category == ApplicationInfo.CATEGORY_GAME ||
                    pkg in KNOWN_GAME_PACKAGES ||
                    pkg.contains("game", ignoreCase = true) ||
                    pkg.contains("freefire", ignoreCase = true) ||
                    pkg.contains("roblox", ignoreCase = true)
                val icon = runCatching { drawableToImageBitmap(pm.getApplicationIcon(info)) }.getOrNull()
                InstalledGame(
                  appName = appName,
                  packageName = pkg,
                  isFeatured = pkg in featuredPackages,
                  isGameCategory = isGame,
                  isInstalled = true,
                  iconBitmap = icon,
                )
              }
              .getOrNull()
          }
          .sortedWith(
            compareByDescending<InstalledGame> { it.isFeatured }
              .thenByDescending { it.isGameCategory }
              .thenBy { it.appName.lowercase() }
          )

      featuredList to allInstalled
    }

  fun savePreparedProfile(
    packageName: String?,
    gameName: String?,
    fpsMode: FpsMode,
    enabledTweakIds: Set<String>,
  ) {
    runCatching {
      prefs
        .edit()
        .putString(KEY_SELECTED_PACKAGE, packageName)
        .putString(KEY_SELECTED_GAME_NAME, gameName)
        .putString(KEY_SELECTED_FPS_MODE, fpsMode.id)
        .putStringSet(KEY_ENABLED_TWEAKS, enabledTweakIds)
        .apply()
    }
  }

  fun loadPreparedProfile(): PreparedProfileSnapshot {
    return runCatching {
        val pkg = prefs.getString(KEY_SELECTED_PACKAGE, null)
        val name = prefs.getString(KEY_SELECTED_GAME_NAME, null)
        val fps = FpsMode.fromId(prefs.getString(KEY_SELECTED_FPS_MODE, FpsMode.FPS_120.id))
        val tweaks =
          prefs.getStringSet(KEY_ENABLED_TWEAKS, DefaultTweaksProvider.defaultRecommendedIds)
            ?: DefaultTweaksProvider.defaultRecommendedIds
        PreparedProfileSnapshot(
          packageName = pkg,
          gameName = name,
          fpsMode = fps,
          enabledTweakIds = tweaks.toSet(),
        )
      }
      .getOrDefault(
        PreparedProfileSnapshot(
          packageName = null,
          gameName = null,
          fpsMode = FpsMode.FPS_120,
          enabledTweakIds = DefaultTweaksProvider.defaultRecommendedIds,
        )
      )
  }

  fun launchGame(packageName: String): Boolean {
    return runCatching {
        val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName) ?: return false
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(launchIntent)
        true
      }
      .getOrDefault(false)
  }

  private fun drawableToImageBitmap(drawable: Drawable): ImageBitmap? {
    return runCatching {
        val bitmap =
          if (drawable is BitmapDrawable && drawable.bitmap != null) {
            drawable.bitmap
          } else {
            val width = drawable.intrinsicWidth.coerceIn(48, 128)
            val height = drawable.intrinsicHeight.coerceIn(48, 128)
            val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            drawable.setBounds(0, 0, canvas.width, canvas.height)
            drawable.draw(canvas)
            bmp
          }
        bitmap.asImageBitmap()
      }
      .getOrNull()
  }
}
