package com.raylan.vrxotmz.overlay

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.TypedValue
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.raylan.vrxotmz.MainActivity
import com.raylan.vrxotmz.R
import com.raylan.vrxotmz.data.GameRepository
import com.raylan.vrxotmz.model.DefaultTweaksProvider
import com.raylan.vrxotmz.model.FpsMode
import com.raylan.vrxotmz.shizuku.ShizukuEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

class FloatingOverlayService : Service() {

  companion object {
    private const val CHANNEL_ID = "vrx_otmz_overlay_channel"
    private const val NOTIFICATION_ID = 4096

    private val _isOverlayRunning = MutableStateFlow(false)
    val isOverlayRunning: StateFlow<Boolean> = _isOverlayRunning.asStateFlow()
  }

  private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
  private lateinit var windowManager: WindowManager
  private lateinit var shizukuEngine: ShizukuEngine
  private lateinit var gameRepository: GameRepository

  private var rootContainer: LinearLayout? = null
  private var pillView: LinearLayout? = null
  private var panelView: LinearLayout? = null
  private var pillFpsText: TextView? = null
  private var pillDotView: View? = null
  private var panelFpsBadge: TextView? = null
  private var panelStatusText: TextView? = null
  private var panelTargetText: TextView? = null
  private var layoutParams: WindowManager.LayoutParams? = null

  private val fpsButtons = mutableMapOf<FpsMode, TextView>()
  private var selectedFpsMode: FpsMode = FpsMode.FPS_120
  private var isExpanded = false
  private var isChoreographerRunning = false

  private var frameCount = 0
  private var lastFrameTimeNanos = 0L

  private val frameCallback =
    object : Choreographer.FrameCallback {
      override fun doFrame(frameTimeNanos: Long) {
        if (!isChoreographerRunning) return
        runCatching {
          if (lastFrameTimeNanos == 0L) {
            lastFrameTimeNanos = frameTimeNanos
            frameCount = 0
          } else {
            frameCount++
            val elapsedNanos = frameTimeNanos - lastFrameTimeNanos
            if (elapsedNanos >= 500_000_000L) {
              val currentFps =
                ((frameCount * 1_000_000_000.0) / elapsedNanos).roundToInt().coerceIn(1, 300)
              updateFpsReadout(currentFps)
              frameCount = 0
              lastFrameTimeNanos = frameTimeNanos
            }
          }
          Choreographer.getInstance().postFrameCallback(this)
        }
      }
    }

  override fun onCreate() {
    super.onCreate()
    windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    shizukuEngine = ShizukuEngine(applicationContext)
    gameRepository = GameRepository(applicationContext)

    startOverlayForeground()

    val canDraw = runCatching { Settings.canDrawOverlays(this) }.getOrDefault(false)
    if (!canDraw) {
      stopSelf()
      return
    }

    val snapshot = gameRepository.loadPreparedProfile()
    selectedFpsMode = snapshot.fpsMode

    runCatching {
      setupOverlayViews(snapshot.gameName, snapshot.packageName)
      startFpsMonitor()
      _isOverlayRunning.value = true
    }.onFailure {
      stopSelf()
    }
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    runCatching {
      val snapshot = gameRepository.loadPreparedProfile()
      selectedFpsMode = snapshot.fpsMode
      refreshFpsShortcutStyles()
      panelTargetText?.text =
        "ALVO: ${snapshot.gameName ?: snapshot.packageName ?: "Nenhum jogo selecionado"}"
    }
    return START_STICKY
  }

  override fun onBind(intent: Intent?): IBinder? = null

  override fun onDestroy() {
    super.onDestroy()
    isChoreographerRunning = false
    runCatching { Choreographer.getInstance().removeFrameCallback(frameCallback) }
    runCatching {
      rootContainer?.let { view -> windowManager.removeView(view) }
      rootContainer = null
    }
    runCatching { shizukuEngine.unbindUserService() }
    _isOverlayRunning.value = false
    serviceScope.cancel()
  }

  private fun startOverlayForeground() {
    runCatching {
      val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
      val channel =
        NotificationChannel(
          CHANNEL_ID,
          getString(R.string.overlay_channel_name),
          NotificationManager.IMPORTANCE_LOW,
        )
      nm.createNotificationChannel(channel)

      val openAppIntent =
        PendingIntent.getActivity(
          this,
          0,
          Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
          },
          PendingIntent.FLAG_IMMUTABLE,
        )

      val notification: Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
          .setSmallIcon(R.mipmap.ic_launcher)
          .setContentTitle(getString(R.string.overlay_notification_title))
          .setContentText(getString(R.string.overlay_notification_text))
          .setOngoing(true)
          .setContentIntent(openAppIntent)
          .build()

      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
        startForeground(
          NOTIFICATION_ID,
          notification,
          ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE,
        )
      } else {
        startForeground(NOTIFICATION_ID, notification)
      }
    }
  }

  private fun startFpsMonitor() {
    isChoreographerRunning = true
    frameCount = 0
    lastFrameTimeNanos = 0L
    runCatching { Choreographer.getInstance().postFrameCallback(frameCallback) }
  }

  private fun updateFpsReadout(fps: Int) {
    val color =
      when {
        fps >= 55 -> Color.parseColor("#00FF66")
        fps >= 35 -> Color.parseColor("#00E5FF")
        else -> Color.parseColor("#FFB300")
      }
    pillFpsText?.apply {
      text = "$fps FPS"
      setTextColor(color)
    }
    pillDotView?.background =
      GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
      }
    panelFpsBadge?.apply {
      text = "$fps FPS"
      setTextColor(color)
    }
  }

  @SuppressLint("ClickableViewAccessibility")
  private fun setupOverlayViews(gameName: String?, packageName: String?) {
    val root =
      LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.TOP or Gravity.START
      }

    val pill = buildFloatingPill()
    val panel = buildExpandedPanel(gameName, packageName)
    panel.visibility = View.GONE

    root.addView(pill)
    root.addView(panel)
    rootContainer = root
    pillView = pill
    panelView = panel

    val params =
      WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
          WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT,
      ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = dp(16)
        y = dp(96)
      }
    layoutParams = params

    var initialX = 0
    var initialY = 0
    var touchStartX = 0f
    var touchStartY = 0f
    var hasMoved = false

    pill.setOnTouchListener { _, event ->
      when (event.actionMasked) {
        MotionEvent.ACTION_DOWN -> {
          initialX = params.x
          initialY = params.y
          touchStartX = event.rawX
          touchStartY = event.rawY
          hasMoved = false
          true
        }
        MotionEvent.ACTION_MOVE -> {
          val dx = (event.rawX - touchStartX).roundToInt()
          val dy = (event.rawY - touchStartY).roundToInt()
          if (abs(dx) > 8 || abs(dy) > 8) {
            hasMoved = true
            params.x = initialX + dx
            params.y = initialY + dy
            runCatching { windowManager.updateViewLayout(root, params) }
          }
          true
        }
        MotionEvent.ACTION_UP -> {
          if (!hasMoved) {
            toggleExpandedPanel()
          }
          true
        }
        else -> false
      }
    }

    windowManager.addView(root, params)
  }

  private fun buildFloatingPill(): LinearLayout {
    val container =
      LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(10), dp(7), dp(12), dp(7))
        background =
          GradientDrawable().apply {
            setColor(Color.parseColor("#E6060913"))
            cornerRadius = dp(20).toFloat()
            setStroke(dp(1), Color.parseColor("#00E5FF"))
          }
      }

    val dot =
      View(this).apply {
        layoutParams = LinearLayout.LayoutParams(dp(8), dp(8)).apply { rightMargin = dp(6) }
        background =
          GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor("#00FF66"))
          }
      }
    pillDotView = dot

    val fpsText =
      TextView(this).apply {
        text = "-- FPS"
        setTextColor(Color.parseColor("#00FF66"))
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
      }
    pillFpsText = fpsText

    val badge =
      TextView(this).apply {
        text = "  VRX"
        setTextColor(Color.parseColor("#00E5FF"))
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
      }

    container.addView(dot)
    container.addView(fpsText)
    container.addView(badge)
    return container
  }

  private fun buildExpandedPanel(gameName: String?, packageName: String?): LinearLayout {
    val panel =
      LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(12), dp(14), dp(12))
        layoutParams = LinearLayout.LayoutParams(dp(268), LinearLayout.LayoutParams.WRAP_CONTENT)
        background =
          GradientDrawable().apply {
            setColor(Color.parseColor("#F20C1222"))
            cornerRadius = dp(16).toFloat()
            setStroke(dp(1), Color.parseColor("#00E5FF"))
          }
      }

    val headerRow =
      LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
      }

    val titleView =
      TextView(this).apply {
        text = "VRX OTMZ • HUD"
        setTextColor(Color.parseColor("#00E5FF"))
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
      }

    val liveFpsBadge =
      TextView(this).apply {
        text = "-- FPS"
        setTextColor(Color.parseColor("#00FF66"))
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        setPadding(dp(6), dp(2), dp(6), dp(2))
      }
    panelFpsBadge = liveFpsBadge

    val collapseBtn =
      TextView(this).apply {
        text = " ✕ "
        setTextColor(Color.parseColor("#F1F6FF"))
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        setPadding(dp(6), dp(2), dp(4), dp(2))
        setOnClickListener { toggleExpandedPanel() }
      }

    headerRow.addView(titleView)
    headerRow.addView(liveFpsBadge)
    headerRow.addView(collapseBtn)
    panel.addView(headerRow)

    val targetView =
      TextView(this).apply {
        text = "ALVO: ${gameName ?: packageName ?: "Nenhum jogo selecionado"}"
        setTextColor(Color.parseColor("#8CA0C4"))
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
        typeface = Typeface.MONOSPACE
        setPadding(0, dp(4), 0, dp(8))
      }
    panelTargetText = targetView
    panel.addView(targetView)

    val shortcutsRow =
      LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER
      }

    FpsMode.entries.forEachIndexed { idx, mode ->
      val label = if (mode == FpsMode.FPS_300) "300 FPS" else mode.shortLabel
      val chip =
        TextView(this).apply {
          text = label
          gravity = Gravity.CENTER
          setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
          typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
          setPadding(dp(4), dp(8), dp(4), dp(8))
          layoutParams =
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
              if (idx < FpsMode.entries.lastIndex) rightMargin = dp(5)
            }
          setOnClickListener {
            selectedFpsMode = mode
            val snapshot = gameRepository.loadPreparedProfile()
            gameRepository.savePreparedProfile(
              packageName = snapshot.packageName,
              gameName = snapshot.gameName,
              fpsMode = mode,
              enabledTweakIds = snapshot.enabledTweakIds,
            )
            refreshFpsShortcutStyles()
            panelStatusText?.text = "Perfil ${mode.title} selecionado. Toque TURBINA BOOST."
          }
        }
      fpsButtons[mode] = chip
      shortcutsRow.addView(chip)
    }
    refreshFpsShortcutStyles()
    panel.addView(shortcutsRow)

    val boostButton =
      TextView(this).apply {
        text = "⚡ TURBINA BOOST"
        gravity = Gravity.CENTER
        setTextColor(Color.parseColor("#060913"))
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        setPadding(dp(10), dp(10), dp(10), dp(10))
        layoutParams =
          LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT,
          ).apply {
            topMargin = dp(10)
          }
        background =
          GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(Color.parseColor("#00E5FF"), Color.parseColor("#00FF66")),
          ).apply {
            cornerRadius = dp(10).toFloat()
          }
        setOnClickListener { applyOverlayBoost() }
      }
    panel.addView(boostButton)

    val bottomRow =
      LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        layoutParams =
          LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT,
          ).apply {
            topMargin = dp(8)
          }
      }

    val restoreBtn =
      TextView(this).apply {
        text = "RESTAURAR"
        gravity = Gravity.CENTER
        setTextColor(Color.parseColor("#00E5FF"))
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        setPadding(dp(6), dp(8), dp(6), dp(8))
        layoutParams =
          LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            rightMargin = dp(6)
          }
        background =
          GradientDrawable().apply {
            setColor(Color.parseColor("#121C33"))
            cornerRadius = dp(8).toFloat()
            setStroke(dp(1), Color.parseColor("#1E2D4D"))
          }
        setOnClickListener { restoreFromOverlay() }
      }

    val stopBtn =
      TextView(this).apply {
        text = "OCULTAR HUD"
        gravity = Gravity.CENTER
        setTextColor(Color.parseColor("#FF2E55"))
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        setPadding(dp(6), dp(8), dp(6), dp(8))
        layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        background =
          GradientDrawable().apply {
            setColor(Color.parseColor("#1A0D18"))
            cornerRadius = dp(8).toFloat()
            setStroke(dp(1), Color.parseColor("#55FF2E55"))
          }
        setOnClickListener { stopSelf() }
      }

    bottomRow.addView(restoreBtn)
    bottomRow.addView(stopBtn)
    panel.addView(bottomRow)

    val statusText =
      TextView(this).apply {
        text = "Pronto para otimização instantânea."
        setTextColor(Color.parseColor("#8CA0C4"))
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
        typeface = Typeface.MONOSPACE
        setPadding(0, dp(8), 0, 0)
      }
    panelStatusText = statusText
    panel.addView(statusText)

    return panel
  }

  private fun refreshFpsShortcutStyles() {
    fpsButtons.forEach { (mode, view) ->
      val selected = mode == selectedFpsMode
      view.setTextColor(
        if (selected) Color.parseColor("#060913") else Color.parseColor("#F1F6FF")
      )
      view.background =
        GradientDrawable().apply {
          setColor(
            if (selected) Color.parseColor("#00E5FF") else Color.parseColor("#121C33")
          )
          cornerRadius = dp(8).toFloat()
          setStroke(
            dp(1),
            if (selected) Color.parseColor("#00FF66") else Color.parseColor("#1E2D4D"),
          )
        }
    }
  }

  private fun toggleExpandedPanel() {
    isExpanded = !isExpanded
    runCatching {
      pillView?.visibility = if (isExpanded) View.GONE else View.VISIBLE
      panelView?.visibility = if (isExpanded) View.VISIBLE else View.GONE
      val root = rootContainer ?: return
      val params = layoutParams ?: return
      windowManager.updateViewLayout(root, params)
    }
  }

  private fun applyOverlayBoost() {
    val snapshot = gameRepository.loadPreparedProfile()
    val pkg = snapshot.packageName
    if (pkg.isNullOrBlank()) {
      panelStatusText?.apply {
        text = "Abra o VRX OTMZ e escolha um jogo antes de aplicar."
        setTextColor(Color.parseColor("#FFB300"))
      }
      return
    }

    val enabledTweaks =
      DefaultTweaksProvider.createDefaultTweaks(snapshot.enabledTweakIds).filter { it.isEnabled }

    serviceScope.launch {
      panelStatusText?.apply {
        text = "Aplicando ${selectedFpsMode.title}..."
        setTextColor(Color.parseColor("#00E5FF"))
      }

      val result =
        shizukuEngine.applyTurbinaBoost(
          packageName = pkg,
          fpsMode = selectedFpsMode,
          enabledTweaks = enabledTweaks,
          onProgress = { step, total, label ->
            panelStatusText?.text = "[$step/$total] $label"
          },
        )

      if (result.success) {
        panelStatusText?.apply {
          text = "Turbina Boost Ativo! (${selectedFpsMode.title})"
          setTextColor(Color.parseColor("#00FF66"))
        }
      } else {
        panelStatusText?.apply {
          text = result.errorMessage ?: "Erro ao executar via Shizuku."
          setTextColor(Color.parseColor("#FF2E55"))
        }
      }
    }
  }

  private fun restoreFromOverlay() {
    val snapshot = gameRepository.loadPreparedProfile()
    serviceScope.launch {
      panelStatusText?.apply {
        text = "Restaurando padrão do sistema..."
        setTextColor(Color.parseColor("#00E5FF"))
      }
      val result = shizukuEngine.restoreDefaults(snapshot.packageName)
      if (result.success) {
        panelStatusText?.apply {
          text = "Padrão restaurado com sucesso."
          setTextColor(Color.parseColor("#00FF66"))
        }
      } else {
        panelStatusText?.apply {
          text = result.errorMessage ?: "Shizuku necessário para restaurar."
          setTextColor(Color.parseColor("#FF2E55"))
        }
      }
    }
  }

  private fun dp(value: Int): Int {
    return TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP,
        value.toFloat(),
        resources.displayMetrics,
      )
      .roundToInt()
  }
}
