package com.raylan.vrxotmz.shizuku

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.hardware.display.DisplayManager
import android.os.IBinder
import android.view.Display
import com.raylan.vrxotmz.BuildConfig
import com.raylan.vrxotmz.IShellService
import com.raylan.vrxotmz.model.FpsMode
import com.raylan.vrxotmz.model.OptimizationTweak
import com.raylan.vrxotmz.model.ShizukuStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader

data class BoostExecutionResult(
  val success: Boolean,
  val appliedCount: Int,
  val maxHardwareHz: Float,
  val logs: List<String>,
  val errorMessage: String? = null,
)

class ShizukuEngine(private val context: Context) {

  companion object {
    const val SHIZUKU_PERMISSION_REQUEST_CODE = 1001
  }

  @Volatile private var shellService: IShellService? = null
  @Volatile private var isBindingService = false

  private val userServiceConnection =
    object : ServiceConnection {
      override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
        runCatching { shellService = IShellService.Stub.asInterface(service) }
        isBindingService = false
      }

      override fun onServiceDisconnected(name: ComponentName?) {
        shellService = null
        isBindingService = false
      }
    }

  private val userServiceArgs: Shizuku.UserServiceArgs by lazy {
    Shizuku.UserServiceArgs(ComponentName(context.packageName, ShellUserService::class.java.name))
      .daemon(false)
      .processNameSuffix("vrx_shell")
      .debuggable(BuildConfig.DEBUG)
      .version(BuildConfig.VERSION_CODE)
  }

  fun getStatus(): ShizukuStatus {
    return runCatching {
        val alive = Shizuku.pingBinder()
        if (!alive) {
          ShizukuStatus.NotRunning
        } else {
          val granted = Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
          if (granted) {
            ensureUserServiceBound()
            val uid = runCatching { Shizuku.getUid() }.getOrDefault(2000)
            val version = runCatching { Shizuku.getVersion() }.getOrDefault(13)
            ShizukuStatus.Authorized(uid = uid, version = version)
          } else {
            ShizukuStatus.PermissionRequired
          }
        }
      }
      .getOrDefault(ShizukuStatus.NotRunning)
  }

  fun requestPermissionIfNeeded(): Boolean {
    return runCatching {
        if (Shizuku.pingBinder() && Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
          Shizuku.requestPermission(SHIZUKU_PERMISSION_REQUEST_CODE)
          true
        } else {
          false
        }
      }
      .getOrDefault(false)
  }

  fun ensureUserServiceBound() {
    runCatching {
      if (
        shellService == null &&
          !isBindingService &&
          Shizuku.pingBinder() &&
          Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
      ) {
        isBindingService = true
        Shizuku.bindUserService(userServiceArgs, userServiceConnection)
      }
    }.onFailure { isBindingService = false }
  }

  fun unbindUserService() {
    runCatching {
      if (shellService != null) {
        Shizuku.unbindUserService(userServiceArgs, userServiceConnection, true)
        shellService = null
      }
    }
  }

  fun detectMaxHardwareRefreshRate(): Float {
    return runCatching {
        val displayManager =
          context.getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager
        val display: Display? = displayManager?.getDisplay(Display.DEFAULT_DISPLAY)
        val modes = display?.supportedModes
        val maxMode = modes?.maxOfOrNull { it.refreshRate } ?: display?.refreshRate ?: 120f
        maxMode.coerceAtLeast(60f)
      }
      .getOrDefault(120f)
  }

  suspend fun applyTurbinaBoost(
    packageName: String,
    fpsMode: FpsMode,
    enabledTweaks: List<OptimizationTweak>,
    onProgress: (step: Int, total: Int, label: String) -> Unit,
  ): BoostExecutionResult =
    withContext(Dispatchers.IO) {
      val status = getStatus()
      if (status !is ShizukuStatus.Authorized) {
        return@withContext BoostExecutionResult(
          success = false,
          appliedCount = 0,
          maxHardwareHz = detectMaxHardwareRefreshRate(),
          logs = emptyList(),
          errorMessage =
            when (status) {
              ShizukuStatus.NotRunning ->
                "Shizuku inativo. Inicie o serviço Shizuku e tente novamente."
              ShizukuStatus.PermissionRequired ->
                "Permissão do Shizuku pendente. Autorize o VRX OTMZ na janela do sistema."
              is ShizukuStatus.Authorized -> ""
            },
        )
      }

      ensureUserServiceBound()
      val maxHz = detectMaxHardwareRefreshRate()
      val tasks = buildBoostTasks(packageName = packageName, fpsMode = fpsMode, tweaks = enabledTweaks, maxHz = maxHz)
      val logs = mutableListOf<String>()
      val total = tasks.size

      tasks.forEachIndexed { index, task ->
        withContext(Dispatchers.Main) { onProgress(index + 1, total, task.label) }
        val output =
          runCatching {
              val cmdJoined = task.commands.joinToString(" ; ")
              executeShellCommand(cmdJoined)
            }
            .getOrElse { "ERR: ${it.message}" }
        logs += "[${index + 1}/$total] ${task.label} -> $output"
        delay(55L)
      }

      BoostExecutionResult(
        success = true,
        appliedCount = enabledTweaks.size,
        maxHardwareHz = maxHz,
        logs = logs,
      )
    }

  suspend fun restoreDefaults(packageName: String?): BoostExecutionResult =
    withContext(Dispatchers.IO) {
      val status = getStatus()
      if (status !is ShizukuStatus.Authorized) {
        return@withContext BoostExecutionResult(
          success = false,
          appliedCount = 0,
          maxHardwareHz = detectMaxHardwareRefreshRate(),
          logs = emptyList(),
          errorMessage = "Shizuku não está autorizado para restaurar configurações.",
        )
      }

      val pkg = packageName?.takeIf { it.isNotBlank() }
      val commands = buildList {
        add("settings delete system min_refresh_rate")
        add("settings delete system peak_refresh_rate")
        add("settings put global window_animation_scale 1.0")
        add("settings put global transition_animation_scale 1.0")
        add("settings put global animator_duration_scale 1.0")
        add("cmd thermalservice reset")
        add("cmd power set-fixed-performance-mode-enabled false")
        add("cmd power set-adaptive-power-saver-enabled true")
        add("cmd wifi set-low-latency-mode disabled")
        if (pkg != null) {
          add("cmd game mode standard $pkg")
        }
      }

      val logs =
        commands.map { cmd ->
          val res = runCatching { executeShellCommand(cmd) }.getOrElse { "ERR: ${it.message}" }
          "$cmd -> $res"
        }

      BoostExecutionResult(
        success = true,
        appliedCount = commands.size,
        maxHardwareHz = detectMaxHardwareRefreshRate(),
        logs = logs,
      )
    }

  private fun executeShellCommand(command: String): String {
    val boundResult =
      runCatching {
          val service = shellService
          if (service != null && service.asBinder().isBinderAlive) {
            service.runCommand(command)
          } else {
            null
          }
        }
        .getOrNull()

    if (boundResult != null) return boundResult

    return runCatching {
        val newProcessMethod =
          Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java,
          )
        newProcessMethod.isAccessible = true
        val process =
          newProcessMethod.invoke(null, arrayOf("sh", "-c", command), null, null) as Process
        val out = BufferedReader(InputStreamReader(process.inputStream)).use { it.readText().trim() }
        val err = BufferedReader(InputStreamReader(process.errorStream)).use { it.readText().trim() }
        val code = process.waitFor()
        if (code == 0) out.ifEmpty { "OK" } else "EXIT($code): ${err.ifEmpty { out }}"
      }
      .getOrElse { error -> "ERR: ${error.message ?: "exec_failed"}" }
  }

  private data class ShellTask(val label: String, val commands: List<String>)

  private fun buildBoostTasks(
    packageName: String,
    fpsMode: FpsMode,
    tweaks: List<OptimizationTweak>,
    maxHz: Float,
  ): List<ShellTask> {
    val tasks = mutableListOf<ShellTask>()

    val fpsCommands =
      when (fpsMode) {
        FpsMode.FPS_60 ->
          listOf(
            "settings put system min_refresh_rate 60.0",
            "settings put system peak_refresh_rate 60.0",
            "cmd game set --fps 60 $packageName",
            "cmd game mode standard $packageName",
          )
        FpsMode.FPS_100 ->
          listOf(
            "settings put system min_refresh_rate 100.0",
            "settings put system peak_refresh_rate 100.0",
            "cmd game set --fps 100 $packageName",
            "cmd game mode performance $packageName",
          )
        FpsMode.FPS_120 ->
          listOf(
            "settings put system min_refresh_rate 120.0",
            "settings put system peak_refresh_rate 120.0",
            "cmd game set --fps 120 $packageName",
            "cmd game mode performance $packageName",
          )
        FpsMode.FPS_300 -> {
          val maxHzStr = String.format(java.util.Locale.US, "%.1f", maxHz)
          listOf(
            "settings put system min_refresh_rate $maxHzStr",
            "settings put system peak_refresh_rate $maxHzStr",
            "cmd game set --fps 300 $packageName",
            "cmd game mode performance $packageName",
            "setprop debug.egl.swapinterval 0",
          )
        }
      }

    tasks += ShellTask(label = "Perfil ${fpsMode.title}", commands = fpsCommands)

    tweaks.forEach { tweak ->
      val cmds =
        when (tweak.id) {
          "gpu_clock_lock" ->
            listOf(
              "cmd power set-fixed-performance-mode-enabled true",
              "setprop debug.hwui.renderer skiagl",
            )
          "disable_thermal_gos" ->
            listOf(
              "cmd thermalservice override-status 0",
              "am force-stop com.samsung.android.game.gos",
            )
          "render_thread_priority" ->
            listOf(
              "setprop debug.renderengine.backend skiaglthreaded",
              "setprop debug.sf.latch_unsignaled 1",
            )
          "frametime_stabilizer" ->
            listOf(
              "setprop debug.sf.disable_backpressure 1",
              "setprop debug.cpurend.vsync false",
            )
          "vulkan_opengl_cache" ->
            listOf(
              "cmd package trim-caches 512M",
              "pm trim-caches 512M",
            )
          "speed_profile_compile" ->
            listOf("cmd package compile -m speed-profile -f $packageName")
          "touch_latency_reduction" ->
            listOf(
              "settings put secure touch_blocking_enabled 0",
              "settings put system pointer_speed 7",
            )
          "block_bg_sync" ->
            listOf(
              "settings put global auto_sync 0",
              "cmd appops set $packageName RUN_ANY_IN_BACKGROUND allow",
            )
          "ram_trim_boost" ->
            listOf(
              "am kill-all",
              "pm trim-caches 256M",
            )
          "game_mode_performance" ->
            listOf(
              "cmd game mode performance $packageName",
              "cmd game set --mode 2 --downscale 1.0 $packageName",
            )
          "zero_system_animations" ->
            listOf(
              "settings put global window_animation_scale 0.0",
              "settings put global transition_animation_scale 0.0",
              "settings put global animator_duration_scale 0.0",
            )
          "foreground_io_priority" ->
            listOf(
              "cmd activity set-standby-bucket $packageName active",
              "dumpsys deviceidle whitelist +$packageName",
            )
          "disable_adaptive_battery" ->
            listOf(
              "cmd power set-adaptive-power-saver-enabled false",
              "settings put global low_power 0",
            )
          "surfaceflinger_accel" ->
            listOf(
              "setprop debug.hwui.use_buffer_age true",
              "setprop debug.sf.enable_hwc_vds 0",
            )
          "wifi_low_latency" ->
            listOf(
              "cmd wifi set-low-latency-mode enabled",
              "settings put global wifi_sleep_policy 2",
            )
          else -> emptyList()
        }
      if (cmds.isNotEmpty()) {
        tasks += ShellTask(label = tweak.title, commands = cmds)
      }
    }

    return tasks
  }
}
