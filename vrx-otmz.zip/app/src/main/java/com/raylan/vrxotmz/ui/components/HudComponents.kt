package com.raylan.vrxotmz.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PictureInPictureAlt
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.raylan.vrxotmz.model.BoostPhase
import com.raylan.vrxotmz.model.FpsMode
import com.raylan.vrxotmz.model.InstalledGame
import com.raylan.vrxotmz.model.OptimizationTweak
import com.raylan.vrxotmz.model.ShizukuStatus
import com.raylan.vrxotmz.ui.theme.NeonCyan
import com.raylan.vrxotmz.ui.theme.NeonGreen
import com.raylan.vrxotmz.ui.theme.VrxBackground
import com.raylan.vrxotmz.ui.theme.VrxDanger
import com.raylan.vrxotmz.ui.theme.VrxSurface
import com.raylan.vrxotmz.ui.theme.VrxSurfaceBorder
import com.raylan.vrxotmz.ui.theme.VrxSurfaceElevated
import com.raylan.vrxotmz.ui.theme.VrxTextMuted
import com.raylan.vrxotmz.ui.theme.VrxTextPrimary
import com.raylan.vrxotmz.ui.theme.VrxTextSecondary
import com.raylan.vrxotmz.ui.theme.VrxWarning

@Composable
fun CyberHeader(
  shizukuStatus: ShizukuStatus,
  onShizukuClick: () -> Unit,
) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
      Box(
        modifier =
          Modifier.size(44.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(
              Brush.linearGradient(
                colors = listOf(NeonCyan.copy(alpha = 0.22f), NeonGreen.copy(alpha = 0.18f))
              )
            )
            .border(1.dp, NeonCyan.copy(alpha = 0.65f), RoundedCornerShape(12.dp)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = Icons.Filled.Memory,
          contentDescription = "Logotipo VRX OTMZ",
          tint = NeonCyan,
          modifier = Modifier.size(24.dp),
        )
      }
      Spacer(modifier = Modifier.width(12.dp))
      Column {
        Text(
          text = "VRX OTMZ",
          style = MaterialTheme.typography.headlineLarge,
          color = VrxTextPrimary,
          fontSize = 22.sp,
        )
        Text(
          text = "TURBINA SHIZUKU • ENGINE FPS",
          style = MaterialTheme.typography.labelSmall,
          color = NeonCyan,
        )
      }
    }

    val (dotColor, statusLabel, borderColor) =
      when (shizukuStatus) {
        is ShizukuStatus.Authorized -> Triple(NeonGreen, "SHIZUKU OK", NeonGreen.copy(alpha = 0.6f))
        ShizukuStatus.PermissionRequired ->
          Triple(VrxWarning, "AUTORIZAR", VrxWarning.copy(alpha = 0.7f))
        ShizukuStatus.NotRunning -> Triple(VrxDanger, "SHIZUKU OFF", VrxDanger.copy(alpha = 0.6f))
      }

    Surface(
      modifier =
        Modifier.minimumInteractiveComponentSize()
          .clip(RoundedCornerShape(20.dp))
          .clickable(onClick = onShizukuClick)
          .testTag("shizuku_status_badge"),
      color = VrxSurface,
      shape = RoundedCornerShape(20.dp),
      border = BorderStroke(1.dp, borderColor),
    ) {
      Row(
        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(dotColor))
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = statusLabel,
          fontFamily = FontFamily.Monospace,
          fontWeight = FontWeight.Bold,
          fontSize = 11.sp,
          color = dotColor,
        )
      }
    }
  }
}

@Composable
fun BoostStatusBanner(
  boostPhase: BoostPhase,
  preparedCount: Int,
  selectedFpsMode: FpsMode,
  statusMessage: String,
  onLaunchGame: () -> Unit,
  onRestoreDefaults: () -> Unit,
) {
  val accentColor =
    when (boostPhase) {
      is BoostPhase.Active -> NeonGreen
      is BoostPhase.Applying -> NeonCyan
      is BoostPhase.Error -> VrxDanger
      is BoostPhase.Prepared -> NeonCyan
    }

  Surface(
    modifier = Modifier.fillMaxWidth().testTag("boost_status_banner"),
    color = VrxSurface,
    shape = RoundedCornerShape(16.dp),
    border = BorderStroke(1.dp, accentColor.copy(alpha = 0.45f)),
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
          val icon =
            when (boostPhase) {
              is BoostPhase.Active -> Icons.Filled.CheckCircle
              is BoostPhase.Applying -> Icons.Filled.Bolt
              is BoostPhase.Error -> Icons.Filled.Warning
              is BoostPhase.Prepared -> Icons.Filled.Tune
            }
          Icon(
            imageVector = icon,
            contentDescription = "Status da preparação",
            tint = accentColor,
            modifier = Modifier.size(18.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
          val mainText =
            when (boostPhase) {
              is BoostPhase.Prepared ->
                "Pronto • $preparedCount funções preparadas (aguardando ativação)"
              is BoostPhase.Applying ->
                "Aplicando (${boostPhase.currentStep}/${boostPhase.totalSteps}): ${boostPhase.currentLabel}"
              is BoostPhase.Active -> "Turbina Boost Ativo!"
              is BoostPhase.Error -> boostPhase.message
            }
          Text(
            text = mainText,
            style = MaterialTheme.typography.titleSmall,
            color = if (boostPhase is BoostPhase.Error) VrxDanger else VrxTextPrimary,
          )
        }

        if (boostPhase is BoostPhase.Prepared) {
          Surface(
            color = NeonCyan.copy(alpha = 0.12f),
            shape = RoundedCornerShape(8.dp),
            border = BorderStroke(1.dp, NeonCyan.copy(alpha = 0.35f)),
          ) {
            Text(
              text = selectedFpsMode.shortLabel + " FPS",
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.Bold,
              fontSize = 11.sp,
              color = NeonCyan,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            )
          }
        }
      }

      if (boostPhase is BoostPhase.Applying) {
        Spacer(modifier = Modifier.height(10.dp))
        val progress =
          if (boostPhase.totalSteps > 0) {
            boostPhase.currentStep.toFloat() / boostPhase.totalSteps.toFloat()
          } else {
            0f
          }
        LinearProgressIndicator(
          progress = { progress.coerceIn(0f, 1f) },
          modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(4.dp)),
          color = NeonGreen,
          trackColor = VrxSurfaceElevated,
        )
      }

      if (boostPhase is BoostPhase.Active) {
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text =
            "${boostPhase.gameName} • ${boostPhase.fpsMode.title} • ${boostPhase.appliedCount} otimizações aplicadas (Hardware: ${boostPhase.maxHardwareHz.toInt()}Hz)",
          style = MaterialTheme.typography.bodyMedium,
          color = NeonGreen.copy(alpha = 0.9f),
        )
        Spacer(modifier = Modifier.height(10.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Button(
            onClick = onLaunchGame,
            modifier = Modifier.weight(1f).height(48.dp).testTag("launch_game_button"),
            shape = RoundedCornerShape(12.dp),
            colors =
              ButtonDefaults.buttonColors(
                containerColor = NeonGreen,
                contentColor = VrxBackground,
              ),
          ) {
            Icon(
              imageVector = Icons.Filled.PlayArrow,
              contentDescription = "Abrir jogo",
              modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "ABRIR JOGO",
              fontWeight = FontWeight.ExtraBold,
              fontSize = 12.sp,
            )
          }

          OutlinedButton(
            onClick = onRestoreDefaults,
            modifier = Modifier.weight(1f).height(48.dp).testTag("restore_defaults_button"),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, NeonCyan.copy(alpha = 0.6f)),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = NeonCyan),
          ) {
            Icon(
              imageVector = Icons.Filled.Refresh,
              contentDescription = "Restaurar padrão",
              modifier = Modifier.size(16.dp),
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "RESTAURAR",
              fontWeight = FontWeight.Bold,
              fontSize = 12.sp,
            )
          }
        }
      }

      if (statusMessage.isNotBlank()) {
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = statusMessage,
          fontFamily = FontFamily.Monospace,
          fontSize = 11.sp,
          color = NeonCyan,
        )
      }
    }
  }
}

@Composable
fun SectionHeader(
  title: String,
  badge: String,
  accent: Color = NeonCyan,
) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Text(
      text = title,
      fontFamily = FontFamily.Monospace,
      fontWeight = FontWeight.Bold,
      fontSize = 13.sp,
      letterSpacing = 1.sp,
      color = accent,
    )
    Text(
      text = badge,
      fontFamily = FontFamily.Monospace,
      fontSize = 11.sp,
      color = VrxTextSecondary,
    )
  }
}

@Composable
fun FeaturedGameCard(
  game: InstalledGame,
  isSelected: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val borderColor by
    animateColorAsState(
      targetValue =
        when {
          isSelected -> NeonGreen
          game.isInstalled -> VrxSurfaceBorder
          else -> VrxSurfaceBorder.copy(alpha = 0.45f)
        },
      animationSpec = tween(200),
      label = "featuredGameBorder",
    )

  Surface(
    modifier =
      modifier
        .minimumInteractiveComponentSize()
        .clip(RoundedCornerShape(14.dp))
        .clickable(onClick = onClick)
        .testTag("featured_game_${game.packageName}"),
    color = if (isSelected) VrxSurfaceElevated else VrxSurface,
    shape = RoundedCornerShape(14.dp),
    border = BorderStroke(if (isSelected) 1.5.dp else 1.dp, borderColor),
  ) {
    Column(
      modifier = Modifier.padding(10.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      if (game.iconBitmap != null) {
        Image(
          bitmap = game.iconBitmap,
          contentDescription = game.appName,
          modifier = Modifier.size(38.dp).clip(RoundedCornerShape(10.dp)),
        )
      } else {
        Box(
          modifier =
            Modifier.size(38.dp)
              .clip(RoundedCornerShape(10.dp))
              .background(VrxSurfaceElevated),
          contentAlignment = Alignment.Center,
        ) {
          Icon(
            imageVector = Icons.Filled.SportsEsports,
            contentDescription = game.appName,
            tint = if (game.isInstalled) NeonCyan else VrxTextMuted,
            modifier = Modifier.size(22.dp),
          )
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      Text(
        text = game.appName,
        style = MaterialTheme.typography.titleMedium,
        fontSize = 12.sp,
        color = if (game.isInstalled) VrxTextPrimary else VrxTextSecondary,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )

      Spacer(modifier = Modifier.height(4.dp))

      Text(
        text =
          when {
            isSelected -> "ATIVO"
            game.isInstalled -> "PRONTO"
            else -> "AUSENTE"
          },
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Bold,
        fontSize = 10.sp,
        color =
          when {
            isSelected -> NeonGreen
            game.isInstalled -> NeonCyan
            else -> VrxTextMuted
          },
      )
    }
  }
}

@Composable
fun SelectedGameSelectorBar(
  selectedGame: InstalledGame?,
  totalInstalledCount: Int,
  onOpenPicker: () -> Unit,
) {
  Surface(
    modifier =
      Modifier.fillMaxWidth()
        .minimumInteractiveComponentSize()
        .clip(RoundedCornerShape(14.dp))
        .clickable(onClick = onOpenPicker)
        .testTag("open_game_picker_button"),
    color = VrxSurface,
    shape = RoundedCornerShape(14.dp),
    border = BorderStroke(1.dp, NeonCyan.copy(alpha = 0.45f)),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
        if (selectedGame?.iconBitmap != null) {
          Image(
            bitmap = selectedGame.iconBitmap,
            contentDescription = selectedGame.appName,
            modifier = Modifier.size(36.dp).clip(RoundedCornerShape(9.dp)),
          )
        } else {
          Box(
            modifier =
              Modifier.size(36.dp)
                .clip(RoundedCornerShape(9.dp))
                .background(VrxSurfaceElevated),
            contentAlignment = Alignment.Center,
          ) {
            Icon(
              imageVector = Icons.Filled.SportsEsports,
              contentDescription = "Jogo selecionado",
              tint = NeonCyan,
              modifier = Modifier.size(20.dp),
            )
          }
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
          Text(
            text = selectedGame?.appName ?: "Selecionar qualquer jogo instalado",
            style = MaterialTheme.typography.titleMedium,
            color = VrxTextPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
          Text(
            text = selectedGame?.packageName ?: "$totalInstalledCount aplicativos detectados",
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            color = VrxTextSecondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }
      }

      Spacer(modifier = Modifier.width(8.dp))

      Surface(
        color = NeonCyan.copy(alpha = 0.14f),
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, NeonCyan.copy(alpha = 0.5f)),
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Icon(
            imageVector = Icons.Filled.Search,
            contentDescription = "Buscar jogos",
            tint = NeonCyan,
            modifier = Modifier.size(16.dp),
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = "BUSCAR",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            color = NeonCyan,
          )
        }
      }
    }
  }
}

@Composable
fun FpsModeCard(
  mode: FpsMode,
  isSelected: Boolean,
  maxHardwareHz: Float,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val borderColor by
    animateColorAsState(
      targetValue = if (isSelected) NeonCyan else VrxSurfaceBorder,
      animationSpec = tween(180),
      label = "fpsBorder",
    )

  Surface(
    modifier =
      modifier
        .minimumInteractiveComponentSize()
        .clip(RoundedCornerShape(16.dp))
        .clickable(onClick = onClick)
        .testTag("fps_mode_${mode.id}"),
    color = if (isSelected) VrxSurfaceElevated else VrxSurface,
    shape = RoundedCornerShape(16.dp),
    border = BorderStroke(if (isSelected) 1.5.dp else 1.dp, borderColor),
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = mode.shortLabel,
          fontFamily = FontFamily.Monospace,
          fontWeight = FontWeight.ExtraBold,
          fontSize = 24.sp,
          color = if (isSelected) NeonGreen else NeonCyan,
        )
        Icon(
          imageVector = Icons.Filled.Speed,
          contentDescription = mode.title,
          tint = if (isSelected) NeonGreen else VrxTextMuted,
          modifier = Modifier.size(18.dp),
        )
      }

      Spacer(modifier = Modifier.height(6.dp))

      Text(
        text = mode.title,
        style = MaterialTheme.typography.titleMedium,
        fontSize = 13.sp,
        color = VrxTextPrimary,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )

      Spacer(modifier = Modifier.height(3.dp))

      val detailText =
        if (mode == FpsMode.FPS_300) {
          "Motor 300 FPS • ${maxHardwareHz.toInt()}Hz máx"
        } else {
          mode.subtitle
        }

      Text(
        text = detailText,
        style = MaterialTheme.typography.bodyMedium,
        fontSize = 11.sp,
        color = VrxTextSecondary,
        maxLines = 2,
        overflow = TextOverflow.Ellipsis,
      )
    }
  }
}

@Composable
fun FloatingOverlayControlCard(
  isOverlayActive: Boolean,
  hasOverlayPermission: Boolean,
  onToggleOverlay: () -> Unit,
) {
  Surface(
    modifier = Modifier.fillMaxWidth(),
    color = VrxSurface,
    shape = RoundedCornerShape(16.dp),
    border =
      BorderStroke(
        1.dp,
        if (isOverlayActive) NeonGreen.copy(alpha = 0.65f) else VrxSurfaceBorder,
      ),
  ) {
    Row(
      modifier = Modifier.padding(14.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
        Box(
          modifier =
            Modifier.size(40.dp)
              .clip(RoundedCornerShape(10.dp))
              .background(
                if (isOverlayActive) NeonGreen.copy(alpha = 0.16f)
                else NeonCyan.copy(alpha = 0.12f)
              ),
          contentAlignment = Alignment.Center,
        ) {
          Icon(
            imageVector = Icons.Filled.PictureInPictureAlt,
            contentDescription = "Contador flutuante de FPS",
            tint = if (isOverlayActive) NeonGreen else NeonCyan,
            modifier = Modifier.size(22.dp),
          )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column {
          Text(
            text = "Contador FPS Flutuante",
            style = MaterialTheme.typography.titleMedium,
            color = VrxTextPrimary,
          )
          Text(
            text =
              when {
                isOverlayActive -> "Ativo na tela • Toque na bolha dentro do jogo"
                hasOverlayPermission -> "Exibe FPS real-time + mini-painel no jogo"
                else -> "Requer permissão de sobreposição (SYSTEM_ALERT_WINDOW)"
              },
            style = MaterialTheme.typography.bodyMedium,
            fontSize = 12.sp,
            color = if (isOverlayActive) NeonGreen else VrxTextSecondary,
          )
        }
      }

      Spacer(modifier = Modifier.width(10.dp))

      Button(
        onClick = onToggleOverlay,
        modifier = Modifier.height(48.dp).testTag("toggle_overlay_button"),
        shape = RoundedCornerShape(12.dp),
        contentPadding = PaddingValues(horizontal = 14.dp),
        colors =
          ButtonDefaults.buttonColors(
            containerColor = if (isOverlayActive) VrxDanger else NeonCyan,
            contentColor = if (isOverlayActive) VrxTextPrimary else VrxBackground,
          ),
      ) {
        Text(
          text =
            when {
              isOverlayActive -> "DESATIVAR"
              hasOverlayPermission -> "ATIVAR HUD"
              else -> "PERMITIR"
            },
          fontFamily = FontFamily.Monospace,
          fontWeight = FontWeight.ExtraBold,
          fontSize = 11.sp,
        )
      }
    }
  }
}

@Composable
fun OptimizationTweakCard(
  tweak: OptimizationTweak,
  onToggle: () -> Unit,
) {
  val borderColor by
    animateColorAsState(
      targetValue = if (tweak.isEnabled) NeonCyan.copy(alpha = 0.6f) else VrxSurfaceBorder,
      animationSpec = tween(180),
      label = "tweakBorder",
    )

  Surface(
    modifier =
      Modifier.fillMaxWidth()
        .clip(RoundedCornerShape(14.dp))
        .clickable(onClick = onToggle)
        .testTag("tweak_card_${tweak.id}"),
    color = if (tweak.isEnabled) VrxSurfaceElevated else VrxSurface,
    shape = RoundedCornerShape(14.dp),
    border = BorderStroke(1.dp, borderColor),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = tweak.index.toString().padStart(2, '0'),
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            color = if (tweak.isEnabled) NeonGreen else NeonCyan,
          )
          Spacer(modifier = Modifier.width(8.dp))
          Surface(
            color = VrxBackground,
            shape = RoundedCornerShape(6.dp),
            border = BorderStroke(0.8.dp, VrxSurfaceBorder),
          ) {
            Text(
              text = tweak.category.label,
              fontFamily = FontFamily.Monospace,
              fontSize = 9.sp,
              color = VrxTextSecondary,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
            )
          }
        }
        Spacer(modifier = Modifier.height(5.dp))
        Text(
          text = tweak.title,
          style = MaterialTheme.typography.titleMedium,
          color = VrxTextPrimary,
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = tweak.description,
          style = MaterialTheme.typography.bodyMedium,
          fontSize = 12.sp,
          color = VrxTextSecondary,
        )
      }

      Switch(
        checked = tweak.isEnabled,
        onCheckedChange = { onToggle() },
        modifier = Modifier.testTag("tweak_switch_${tweak.id}"),
        colors =
          SwitchDefaults.colors(
            checkedThumbColor = VrxBackground,
            checkedTrackColor = NeonGreen,
            uncheckedThumbColor = VrxTextSecondary,
            uncheckedTrackColor = VrxBackground,
            uncheckedBorderColor = VrxSurfaceBorder,
          ),
      )
    }
  }
}

@Composable
fun TurbinaBoostBottomDock(
  boostPhase: BoostPhase,
  preparedCount: Int,
  selectedFpsMode: FpsMode,
  onBoostClick: () -> Unit,
) {
  val isApplying = boostPhase is BoostPhase.Applying
  val isActive = boostPhase is BoostPhase.Active

  Surface(
    modifier = Modifier.fillMaxWidth(),
    color = VrxBackground.copy(alpha = 0.96f),
    tonalElevation = 8.dp,
    border = BorderStroke(1.dp, VrxSurfaceBorder),
  ) {
    Column(
      modifier =
        Modifier.fillMaxWidth()
          .navigationBarsPadding()
          .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
      val gradientBrush =
        if (isActive) {
          Brush.horizontalGradient(listOf(NeonGreen, NeonCyan))
        } else {
          Brush.horizontalGradient(listOf(NeonCyan, NeonGreen))
        }

      Box(
        modifier =
          Modifier.fillMaxWidth()
            .height(68.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(gradientBrush)
            .clickable(enabled = !isApplying, onClick = onBoostClick)
            .testTag("turbina_boost_button"),
        contentAlignment = Alignment.Center,
      ) {
        Row(
          modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            Box(
              modifier =
                Modifier.size(42.dp)
                  .clip(CircleShape)
                  .background(VrxBackground.copy(alpha = 0.22f)),
              contentAlignment = Alignment.Center,
            ) {
              Icon(
                imageVector = Icons.Filled.Bolt,
                contentDescription = "Turbina Boost",
                tint = VrxBackground,
                modifier = Modifier.size(26.dp),
              )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
              Text(
                text = if (isApplying) "APLICANDO TURBINA..." else "TURBINA BOOST",
                fontWeight = FontWeight.ExtraBold,
                fontSize = 17.sp,
                letterSpacing = 1.sp,
                color = VrxBackground,
              )
              val subtitleText =
                when (boostPhase) {
                  is BoostPhase.Applying ->
                    "${boostPhase.currentStep}/${boostPhase.totalSteps} • ${boostPhase.currentLabel}"
                  is BoostPhase.Active ->
                    "Turbina Boost Ativo! Toque para reaplicar"
                  else -> "Toque para aplicar todas as funções escolhidas"
                }
              Text(
                text = subtitleText,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = VrxBackground.copy(alpha = 0.86f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            }
          }

          Surface(
            color = VrxBackground.copy(alpha = 0.2f),
            shape = RoundedCornerShape(10.dp),
          ) {
            Text(
              text = "${selectedFpsMode.shortLabel}•$preparedCount",
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.ExtraBold,
              fontSize = 12.sp,
              color = VrxBackground,
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            )
          }
        }
      }
    }
  }
}

@Composable
fun DeveloperFooterCredits() {
  Column(
    modifier = Modifier.fillMaxWidth().padding(vertical = 14.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    Box(
      modifier =
        Modifier.fillMaxWidth(0.5f)
          .height(1.dp)
          .background(
            Brush.horizontalGradient(
              listOf(Color.Transparent, NeonCyan.copy(alpha = 0.5f), Color.Transparent)
            )
          )
    )
    Spacer(modifier = Modifier.height(10.dp))
    Text(
      text = "Desenvolvido por Raylan",
      fontFamily = FontFamily.Monospace,
      fontWeight = FontWeight.SemiBold,
      fontSize = 12.sp,
      letterSpacing = 0.8.sp,
      color = VrxTextSecondary,
      modifier = Modifier.testTag("developer_credits_text"),
    )
    Text(
      text = "VRX OTMZ • com.raylan.vrxotmz",
      fontFamily = FontFamily.Monospace,
      fontSize = 10.sp,
      color = VrxTextMuted,
    )
  }
}
