package com.raylan.vrxotmz.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.raylan.vrxotmz.model.FpsMode
import com.raylan.vrxotmz.model.InstalledGame
import com.raylan.vrxotmz.model.VrxUiState
import com.raylan.vrxotmz.ui.components.BoostStatusBanner
import com.raylan.vrxotmz.ui.components.CyberHeader
import com.raylan.vrxotmz.ui.components.DeveloperFooterCredits
import com.raylan.vrxotmz.ui.components.FeaturedGameCard
import com.raylan.vrxotmz.ui.components.FloatingOverlayControlCard
import com.raylan.vrxotmz.ui.components.FpsModeCard
import com.raylan.vrxotmz.ui.components.OptimizationTweakCard
import com.raylan.vrxotmz.ui.components.SectionHeader
import com.raylan.vrxotmz.ui.components.SelectedGameSelectorBar
import com.raylan.vrxotmz.ui.components.TurbinaBoostBottomDock
import com.raylan.vrxotmz.ui.theme.NeonCyan
import com.raylan.vrxotmz.ui.theme.NeonGreen
import com.raylan.vrxotmz.ui.theme.VrxBackground
import com.raylan.vrxotmz.ui.theme.VrxSurface
import com.raylan.vrxotmz.ui.theme.VrxSurfaceBorder
import com.raylan.vrxotmz.ui.theme.VrxSurfaceElevated
import com.raylan.vrxotmz.ui.theme.VrxTextMuted
import com.raylan.vrxotmz.ui.theme.VrxTextPrimary
import com.raylan.vrxotmz.ui.theme.VrxTextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VrxHomeScreen(
  uiState: VrxUiState,
  onShizukuClick: () -> Unit,
  onSelectGame: (InstalledGame) -> Unit,
  onSearchQueryChange: (String) -> Unit,
  onToggleFilterOnlyGames: () -> Unit,
  onSelectFpsMode: (FpsMode) -> Unit,
  onToggleTweak: (String) -> Unit,
  onSetAllTweaks: (Boolean) -> Unit,
  onTurbinaBoostClick: () -> Unit,
  onLaunchGame: () -> Unit,
  onRestoreDefaults: () -> Unit,
  onToggleOverlay: () -> Unit,
) {
  var showGamePickerSheet by remember { mutableStateOf(false) }

  val filteredGames by
    remember(uiState.games, uiState.searchQuery, uiState.filterOnlyGames) {
      derivedStateOf {
        val query = uiState.searchQuery.trim()
        uiState.games.filter { game ->
          val matchesCategory = !uiState.filterOnlyGames || game.isGameCategory || game.isFeatured
          val matchesQuery =
            query.isEmpty() ||
              game.appName.contains(query, ignoreCase = true) ||
              game.packageName.contains(query, ignoreCase = true)
          matchesCategory && matchesQuery
        }
      }
    }

  Scaffold(
    containerColor = VrxBackground,
    contentWindowInsets = WindowInsets(0, 0, 0, 0),
    bottomBar = {
      TurbinaBoostBottomDock(
        boostPhase = uiState.boostPhase,
        preparedCount = uiState.enabledTweaksCount,
        selectedFpsMode = uiState.selectedFpsMode,
        onBoostClick = onTurbinaBoostClick,
      )
    },
  ) { innerPadding ->
    Box(
      modifier =
        Modifier.fillMaxSize()
          .background(
            Brush.verticalGradient(
              colors = listOf(VrxBackground, VrxSurface.copy(alpha = 0.65f), VrxBackground)
            )
          )
          .padding(innerPadding),
      contentAlignment = Alignment.TopCenter,
    ) {
      LazyColumn(
        modifier = Modifier.widthIn(max = 680.dp).fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
      ) {
        item(key = "header") {
          CyberHeader(
            shizukuStatus = uiState.shizukuStatus,
            onShizukuClick = onShizukuClick,
          )
        }

        item(key = "status_banner") {
          BoostStatusBanner(
            boostPhase = uiState.boostPhase,
            preparedCount = uiState.enabledTweaksCount,
            selectedFpsMode = uiState.selectedFpsMode,
            statusMessage = uiState.statusMessage,
            onLaunchGame = onLaunchGame,
            onRestoreDefaults = onRestoreDefaults,
          )
        }

        item(key = "game_section_header") {
          SectionHeader(
            title = "1. JOGO ALVO",
            badge = "${uiState.games.size} instalados",
          )
        }

        item(key = "featured_games") {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            uiState.featuredGames.forEach { featured ->
              FeaturedGameCard(
                game = featured,
                isSelected = uiState.selectedGame?.packageName == featured.packageName,
                onClick = { onSelectGame(featured) },
                modifier = Modifier.weight(1f),
              )
            }
          }
        }

        item(key = "selected_game_picker") {
          SelectedGameSelectorBar(
            selectedGame = uiState.selectedGame,
            totalInstalledCount = uiState.games.size,
            onOpenPicker = { showGamePickerSheet = true },
          )
        }

        item(key = "fps_section_header") {
          SectionHeader(
            title = "2. TAXA DE QUADROS",
            badge = "Hardware até ${uiState.maxHardwareHz.toInt()}Hz",
          )
        }

        item(key = "fps_modes_grid") {
          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              FpsModeCard(
                mode = FpsMode.FPS_60,
                isSelected = uiState.selectedFpsMode == FpsMode.FPS_60,
                maxHardwareHz = uiState.maxHardwareHz,
                onClick = { onSelectFpsMode(FpsMode.FPS_60) },
                modifier = Modifier.weight(1f),
              )
              FpsModeCard(
                mode = FpsMode.FPS_100,
                isSelected = uiState.selectedFpsMode == FpsMode.FPS_100,
                maxHardwareHz = uiState.maxHardwareHz,
                onClick = { onSelectFpsMode(FpsMode.FPS_100) },
                modifier = Modifier.weight(1f),
              )
            }
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              FpsModeCard(
                mode = FpsMode.FPS_120,
                isSelected = uiState.selectedFpsMode == FpsMode.FPS_120,
                maxHardwareHz = uiState.maxHardwareHz,
                onClick = { onSelectFpsMode(FpsMode.FPS_120) },
                modifier = Modifier.weight(1f),
              )
              FpsModeCard(
                mode = FpsMode.FPS_300,
                isSelected = uiState.selectedFpsMode == FpsMode.FPS_300,
                maxHardwareHz = uiState.maxHardwareHz,
                onClick = { onSelectFpsMode(FpsMode.FPS_300) },
                modifier = Modifier.weight(1f),
              )
            }
          }
        }

        item(key = "overlay_control") {
          FloatingOverlayControlCard(
            isOverlayActive = uiState.isOverlayActive,
            hasOverlayPermission = uiState.hasOverlayPermission,
            onToggleOverlay = onToggleOverlay,
          )
        }

        item(key = "tweaks_header") {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column {
              Text(
                text = "3. 15 FUNÇÕES DE OTIMIZAÇÃO",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                letterSpacing = 1.sp,
                color = NeonCyan,
              )
              Text(
                text = "${uiState.enabledTweaksCount}/15 selecionadas (aplica somente ao ativar)",
                style = MaterialTheme.typography.bodyMedium,
                fontSize = 11.sp,
                color = VrxTextSecondary,
              )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
              TextButton(
                onClick = { onSetAllTweaks(true) },
                modifier = Modifier.testTag("select_all_tweaks_button"),
              ) {
                Text(
                  text = "TODAS",
                  fontFamily = FontFamily.Monospace,
                  fontWeight = FontWeight.Bold,
                  fontSize = 11.sp,
                  color = NeonGreen,
                )
              }
              TextButton(
                onClick = { onSetAllTweaks(false) },
                modifier = Modifier.testTag("clear_all_tweaks_button"),
              ) {
                Text(
                  text = "LIMPAR",
                  fontFamily = FontFamily.Monospace,
                  fontWeight = FontWeight.Bold,
                  fontSize = 11.sp,
                  color = VrxTextSecondary,
                )
              }
            }
          }
        }

        items(items = uiState.tweaks, key = { it.id }) { tweak ->
          OptimizationTweakCard(
            tweak = tweak,
            onToggle = { onToggleTweak(tweak.id) },
          )
        }

        item(key = "developer_credits") {
          DeveloperFooterCredits()
        }
      }
    }
  }

  if (showGamePickerSheet) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
      onDismissRequest = { showGamePickerSheet = false },
      sheetState = sheetState,
      containerColor = VrxSurface,
      contentColor = VrxTextPrimary,
    ) {
      Column(
        modifier =
          Modifier.fillMaxWidth()
            .padding(horizontal = 16.dp)
            .padding(bottom = 24.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = "ESCOLHER JOGO OU APLICATIVO",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = NeonCyan,
          )
          IconButton(onClick = { showGamePickerSheet = false }) {
            Icon(
              imageVector = Icons.Filled.Close,
              contentDescription = "Fechar seletor",
              tint = VrxTextSecondary,
            )
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = uiState.searchQuery,
          onValueChange = onSearchQueryChange,
          modifier = Modifier.fillMaxWidth().testTag("game_search_input"),
          placeholder = {
            Text(
              text = "Buscar Roblox, Free Fire ou qualquer app...",
              color = VrxTextMuted,
              fontSize = 13.sp,
            )
          },
          leadingIcon = {
            Icon(
              imageVector = Icons.Filled.Search,
              contentDescription = "Pesquisar",
              tint = NeonCyan,
            )
          },
          trailingIcon = {
            if (uiState.searchQuery.isNotEmpty()) {
              IconButton(onClick = { onSearchQueryChange("") }) {
                Icon(
                  imageVector = Icons.Filled.Close,
                  contentDescription = "Limpar busca",
                  tint = VrxTextSecondary,
                )
              }
            }
          },
          singleLine = true,
          shape = RoundedCornerShape(14.dp),
          colors =
            OutlinedTextFieldDefaults.colors(
              focusedBorderColor = NeonCyan,
              unfocusedBorderColor = VrxSurfaceBorder,
              focusedTextColor = VrxTextPrimary,
              unfocusedTextColor = VrxTextPrimary,
              focusedContainerColor = VrxBackground,
              unfocusedContainerColor = VrxBackground,
            ),
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          FilterChip(
            selected = !uiState.filterOnlyGames,
            onClick = { if (uiState.filterOnlyGames) onToggleFilterOnlyGames() },
            label = { Text("Todos (${uiState.games.size})", fontSize = 12.sp) },
            colors =
              FilterChipDefaults.filterChipColors(
                selectedContainerColor = NeonCyan.copy(alpha = 0.2f),
                selectedLabelColor = NeonCyan,
              ),
          )
          FilterChip(
            selected = uiState.filterOnlyGames,
            onClick = { if (!uiState.filterOnlyGames) onToggleFilterOnlyGames() },
            label = { Text("Somente Jogos", fontSize = 12.sp) },
            colors =
              FilterChipDefaults.filterChipColors(
                selectedContainerColor = NeonGreen.copy(alpha = 0.2f),
                selectedLabelColor = NeonGreen,
              ),
          )
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (uiState.isLoadingGames) {
          Box(
            modifier = Modifier.fillMaxWidth().height(220.dp),
            contentAlignment = Alignment.Center,
          ) {
            CircularProgressIndicator(color = NeonCyan)
          }
        } else if (filteredGames.isEmpty()) {
          Box(
            modifier = Modifier.fillMaxWidth().height(180.dp),
            contentAlignment = Alignment.Center,
          ) {
            Text(
              text = "Nenhum aplicativo encontrado para \"${uiState.searchQuery}\"",
              color = VrxTextSecondary,
              style = MaterialTheme.typography.bodyMedium,
            )
          }
        } else {
          LazyColumn(
            modifier = Modifier.fillMaxWidth().height(360.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            items(items = filteredGames, key = { it.packageName }) { game ->
              val selected = uiState.selectedGame?.packageName == game.packageName
              Surface(
                modifier =
                  Modifier.fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .clickable {
                      onSelectGame(game)
                      showGamePickerSheet = false
                    }
                    .testTag("game_list_item_${game.packageName}"),
                color = if (selected) VrxSurfaceElevated else VrxBackground,
                shape = RoundedCornerShape(12.dp),
                border =
                  BorderStroke(
                    1.dp,
                    if (selected) NeonGreen else VrxSurfaceBorder,
                  ),
              ) {
                Row(
                  modifier = Modifier.padding(12.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                  Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f),
                  ) {
                    if (game.iconBitmap != null) {
                      Image(
                        bitmap = game.iconBitmap,
                        contentDescription = game.appName,
                        modifier = Modifier.size(36.dp).clip(RoundedCornerShape(8.dp)),
                      )
                    } else {
                      Box(
                        modifier =
                          Modifier.size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(VrxSurface),
                        contentAlignment = Alignment.Center,
                      ) {
                        Icon(
                          imageVector = Icons.Filled.SportsEsports,
                          contentDescription = game.appName,
                          tint = NeonCyan,
                          modifier = Modifier.size(20.dp),
                        )
                      }
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                      Text(
                        text = game.appName,
                        style = MaterialTheme.typography.titleMedium,
                        color = VrxTextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                      )
                      Text(
                        text = game.packageName,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = VrxTextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                      )
                    }
                  }

                  if (selected) {
                    Icon(
                      imageVector = Icons.Filled.Check,
                      contentDescription = "Selecionado",
                      tint = NeonGreen,
                      modifier = Modifier.size(20.dp),
                    )
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
