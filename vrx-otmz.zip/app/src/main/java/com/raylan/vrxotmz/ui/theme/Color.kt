package com.raylan.vrxotmz.ui.theme

import androidx.compose.ui.graphics.Color

val VrxBackground = Color(0xFF060913)
val VrxSurface = Color(0xFF0C1222)
val VrxSurfaceElevated = Color(0xFF121C33)
val VrxSurfaceBorder = Color(0xFF1E2D4D)

val NeonCyan = Color(0xFF00E5FF)
val NeonCyanMuted = Color(0xFF008BA3)
val NeonGreen = Color(0xFF00FF66)
val NeonGreenMuted = Color(0xFF00A844)

val VrxTextPrimary = Color(0xFFF1F6FF)
val VrxTextSecondary = Color(0xFF8CA0C4)
val VrxTextMuted = Color(0xFF56688A)

val VrxWarning = Color(0xFFFFB300)
val VrxDanger = Color(0xFFFF2E55)
val VrxDangerDark = Color(0xFFB71C1C)
